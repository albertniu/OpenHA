/***************************************************************************
 *   Copyright (C) 2008 by Alert Newton                                    *
 *   AlertNewton@qq.com niuguochao@egoonet.com                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef GLOBAL_H
#define GLOBAL_H

#include <sys/io.h>
#include <sys/fcntl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <time.h>
#include <fstream>
#include <vector>
#include <cctype>
#include <algorithm>
#include <qthread.h>
#include <qmutex.h>
#include <qsocket.h>
#include <qstring.h>
#include <qstringlist.h>
#include <qfile.h>
#include <qdatetime.h>
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>

#include "inifile.h"

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FLASE
#define FLASE 0
#endif

extern string g_userName;
extern string g_userPassword;
extern string g_peerURL;
extern string g_gateWayIP;
extern string g_floatingIP;
extern int g_localPort;
extern int g_logLevel;

extern QMutex g_mutexSvrState;
extern QString g_myState;
extern QString g_peerState;

extern QMutex g_mutexRubbish;
extern vector<QSocket*> g_vectorRubbish;

extern int openLogFile();
extern void PRINTF(const char *cpFmt, ...);
extern void writeLog();
extern void loadConfig();
extern void makeDir(const char * destDir, int shareMode);
extern void pushSocket(QSocket *socket);   
extern void popSocket();

extern void initMyState();
extern void setSvrState(QString myState, QString peerState);
extern bool pingHost(const char * host);
extern bool pingGateway();
extern bool pingFloatingIP();
extern bool pingSelf();
extern bool heartBeat();
extern bool findHttpProc(QString proc);
extern bool findLocalProcs();
extern bool findRemoteProcs();

#endif
