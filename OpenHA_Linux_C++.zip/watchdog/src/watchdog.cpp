/***************************************************************************
 *   Copyright (C) 2010 by Albert Newton   *
 *   niuguochao@egoonet.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <qsocket.h>
#include <qserversocket.h>
#include <qapplication.h>
#include <qstring.h>
#include <qtextcodec.h>
#include "writelogthread.h"
#include "rubbishclearthread.h"
#include "heartbeatthread.h"
#include "global.h"

// CHttpDaemon is the the class that implements the simple HTTP server.
class CHttpDaemon : public QServerSocket
{
	Q_OBJECT
public:
    CHttpDaemon( ) : QServerSocket(g_localPort,0)
    {
    }

	void start()
	{
        if ( ok() ) 
			PRINTF ( "Succ:\t listening on %d...", g_localPort );
        else
			PRINTF ( "Error:\t failed to bind to port %d, LINE = %d", g_localPort, __LINE__ );
	}

    void newConnection( int socket )
    {		
        QSocket* s = new QSocket( this );
 		if ( !socket )
		{
			PRINTF ( "Echo:\t FILE = %s, LINE = %d", __FILE__, __LINE__ );
			return;
		}

		connect( s, SIGNAL(readyRead()), this, SLOT(onEventMsgArrival()) );
		s->setSocket( socket );
		pushSocket ( s );
    }
	
	QString readHeader(QSocket* socket)
	{
		if ( !socket )
			return "";

		QString line, header;
		
        while ( socket->canReadLine() ) 
		{
			line = socket->readLine();
			header += line;	
			
			if (line == "\r\n")
				break;
        }

		return header;
	}
	
	QString readBody(QSocket* socket)
	{
		if ( !socket )
			return "";

		QString line, body; 

		while ( socket->canReadLine() ) 
		{
			line = socket->readLine();
			body += line;
			
			if (line == "\r\n")
				break;
        }		

		return body;
	}	                             

private slots:
    void onEventMsgArrival()
    {
        QSocket* socket = (QSocket*)sender();
		if ( !socket )
		{
 			PRINTF ( "Echo:\t FILE = %s, LINE = %d", __FILE__, __LINE__ );
			return;
		}

		const QString localHost = socket->address().toString();
        const QString peerHost = socket->peerAddress().toString();
		const int localPort = socket->port();
		const int peerPort = socket->peerPort();

		if ( g_logLevel > 2 )
	  		PRINTF ( "Echo:\t request from %s:%d to %s:%d, LINE = %d", peerHost.ascii(), peerPort, localHost.ascii(), localPort, __LINE__ );		

		QString header = readHeader( socket );
		QString body = readBody( socket );

		if ( g_logLevel > 2 )
		{
		  	PRINTF ( "Echo:\t client request, socket = %d, header = %s, LINE = %d", socket->socket(), header.ascii(), __LINE__ );
	  		PRINTF ( "Echo:\t client request, socket = %d, body = %s, LINE = %d", socket->socket(), body.ascii(), __LINE__ );
		}

		if ( body == NULL || body == "" )
		{
			body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
			body += "<result>";
			body += "<myState>";
			body += g_myState;
			body += "</myState>";
	
			body += "<peerState>";
			body += g_peerState;
			body += "</peerState>";

			body += "<serverName>WatchDog</serverName>";
			body += "<serverVersion>4.1</serverVersion>";
			body += "</result>";
		}
		else if ( body.find ( "RequestLogin" ) != -1 )
		{
			body.remove ( "\r\n" );
			int begin = body.find ( "RequestLogin|" ) + 13;
			QString account = body.mid ( begin );                   
			QString account2 = g_userName + "|" + g_userPassword;

			if (account == account2)
			{
				body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
				body += "<login>OK</login>";
			}
			else
			{
				body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
				body += "<login>FAIL</login>";
			}
		}
		else if ( body.find ( "RequestStop" ) != -1 )
		{
			body.remove ( "\r\n" );
			int begin = body.find ( "RequestStop|" ) + 12;
			QString server = body.mid ( begin );                   
			QString cmd = "service " + server.lower() + " stop";

			PRINTF ( "%s", cmd.ascii() );
			system ( cmd.ascii ( ) );
			
			body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
			body += "<stop>OK</stop>";
		}
		else if ( body.find ( "RequestRestart" ) != -1 )
		{
			body.remove ( "\r\n" );
			int begin = body.find ( "RequestRestart|" ) + 15;
			QString server = body.mid ( begin );                   
			QString cmd = "service " + server.lower() + " restart";

			PRINTF ( "%s", cmd.ascii() );
			system ( cmd.ascii ( ) );

			body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
			body += "<restart>OK</restart>";
		}
        else
		{
			body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
			body += "<result>";
			body += "<myState>";
			body += g_myState;
			body += "</myState>";
			body += "</result>";
		}

		header = "HTTP/1.0 200 Ok\r\nContent-Type: text/html; charset=\"utf-8\"\r\n\r\n";
		QString response = header + body + "\r\n";	
	
		QTextStream os ( socket );
		os.setEncoding( QTextStream::UnicodeUTF8 );

		QTextCodec *codec = QTextCodec::codecForName ( "utf8" );
		os << codec->toUnicode ( response );

		if ( g_logLevel > 2 )
 			PRINTF ( "%s", response.ascii ( ) );

		socket->close ( );
    }
};

#include "watchdog.moc"

int main( int argc, char** argv )
{
    QApplication app ( argc, argv, false );
                   
	openLogFile ( );
	loadConfig ( );

    CWriteLogThread *wlt = new CWriteLogThread;
    wlt->start ( CWriteLogThread::TimeCriticalPriority );

    CHttpDaemon * httpd = new CHttpDaemon;
	httpd->start ( );
             
	CHeartbeatThread * hbt = new CHeartbeatThread;
	hbt->start ( );

	CRubbishClearThread * rct = new CRubbishClearThread;
	rct->start ( CRubbishClearThread::TimeCriticalPriority );
	
    return app.exec ( );
}
