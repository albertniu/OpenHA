/***************************************************************************
 *   Copyright (C) 2010 by Albert Newton   *
 *   niuguochao@egoonet.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "inifile.h"
#include "global.h"

CIniFile::CIniFile(string filename)
{
	m_sFile = filename;
}

CIniFile::~CIniFile()
{

}

bool CIniFile::GetString(string section, string key, string &value)
{
	FILE *readFile;
	readFile = fopen(m_sFile.data(), "r");
	
	if(!readFile)
	{
		PRINTF ( "Error:\t can't open the file: %s", m_sFile.data() );
		return false;
	}

	char   szBuffer[2048];   
	string sLine;
	bool   bFound = false;
	int    begin;

	section = '[' + section + ']';

	while(fgets(szBuffer, sizeof(szBuffer), readFile))   
	{   
		sLine = szBuffer;
		begin = sLine.find(section) + 1;
		if(begin)
		{
			bFound = true;
			break;
		}
	}

	if(bFound)
	{
		string tempkey = key + '=';
		bFound = false;
		while(fgets(szBuffer, sizeof(szBuffer), readFile))   
		{   
			sLine = szBuffer;
			if(sLine.find("[") != -1)
				break;

			begin = sLine.find(tempkey) + 1;
			if(begin)
			{
				begin = sLine.find_first_of('=', begin) + 1;
				value = sLine.substr(begin);
				bFound = true;
				break;
			}
		}
	}

	if(bFound)
		Trim(value);

	fclose(readFile);

	return bFound;
}

bool CIniFile::GetInteger(string section, string key, int &value)
{
	FILE *readFile;
	readFile = fopen(m_sFile.data(), "r");
	
	if(!readFile)
	{
		PRINTF ( "Error:\t can't open the file: %s", m_sFile.data() );
		return false;
	}

	char   szBuffer[2048];   
	string sLine;
	bool   bFound = false;
	int    begin;
	section = '[' + section + ']';

	while(fgets(szBuffer, sizeof(szBuffer), readFile))   
	{   
		sLine = szBuffer;
		begin = sLine.find(section) + 1;
		if(begin)
		{
			bFound = true;
			break;
		}
	}

	if(bFound)
	{
		string tempkey= key + '=';
		bFound = false;
		while(fgets(szBuffer, sizeof(szBuffer), readFile))   
		{   
			sLine = szBuffer;
			if(sLine.find("[") != -1)
				break;

			begin = sLine.find(tempkey) + 1;
			if(begin)
			{
				begin = sLine.find_first_of('=', begin) + 1;
				value = atoi(sLine.substr(begin).data());
				bFound = true;
				break;
			}
		}
	}

	fclose(readFile);

	return bFound;
}


void CIniFile::LTrim(string &value)
{
	/***************************************************/
	/* notation: don't change the iterator in this case*/
	/***************************************************/
	for(string::iterator it = value.begin(); it != value.end(); )
	{
		if(*it == ' ' || *it == '\t')
		{
			value.erase(it);
		}
		else
		{
			break;
		}
	}
}

void CIniFile::RTrim(string &value)
{
	string::iterator it = value.end();

	while(it != value.begin())
	{
		if(*it == ' ' || *it == '\t' || *it == '\n' || *it == '\r')
		{
			value.erase(it);
		}
		else
		{
			break;
		}

		--it;
	}

	int end = value.find("\r") + 1;
	if(end)
		value = value.substr(0, end-1);

	end = value.find("\n") + 1;
	if(end)
		value = value.substr(0, end-1);
 
	if(value == "\n" || value == "\r" || value == "\r\n")
		value = "";
}

void CIniFile::Trim(string &value)
{
	LTrim(value);
	RTrim(value);
}

