/***************************************************************************
 *   Copyright (C) 2008 by Alert Newton                                    *
 *   AlertNewton@qq.com niuguochao@egoonet.com                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option)t any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "global.h"
#include "inifile.h"

string g_userName;
string g_userPassword;
string g_peerURL;
string g_gateWayIP;
string g_floatingIP;
int g_localPort;
int g_logLevel;

QMutex g_mutexSvrState;
QString g_myState = "slave";
QString g_peerState = "master";

QMutex g_mutexRubbish;
vector<QSocket*> g_vectorRubbish;          

vector<QString> g_vectorLogs;
QMutex g_mutexLog;
int g_iLogFd = 0;

struct PROCESS
{
	string proc;
	string cmd;
	int timewait;
};

vector<PROCESS> g_vectorProcs;
vector<string> g_vectorPeerProcs;

// for test
const char * LogFile = "/etc/watchdog/watchdog.log";
const char * BackupLogFile = "/etc/watchdog/watchdog2.log";

int openLogFile()
{
	remove ( BackupLogFile );
	rename ( LogFile, BackupLogFile );
	
	int fd = open ( LogFile, O_WRONLY | O_CREAT | O_TRUNC, S_IREAD );
	
	if ( fd == -1 )
		printf ( "\nError: Can't create log file: %s\n", LogFile );
	
	g_iLogFd = fd;
	return fd;
}

void PRINTF(const char *cpFmt, ...)
{
	g_mutexLog.lock();
	
	va_list argptr;
	static char buf[4097];
	
	va_start ( argptr, cpFmt );
	vsnprintf ( buf, 4096, cpFmt, argptr );
	va_end ( argptr );

	QDateTime now;
	now.setTime_t ( time ( NULL ) );
		
	QString tmp = now.toString ( "\r\nyyyy-MM-dd hh:mm:ss\t" );
	tmp += buf;
	               
	g_vectorLogs.push_back ( tmp );
	
	g_mutexLog.unlock();
}

void makeDir (const char * destDir, int shareMode)
{
	QString dir = destDir;
	QString subDir;
	
	int begin = 0;
	int pos = 0;
	
	for ( ; ; )
	{
		pos = dir.find ( '/', begin + 1 );
		if ( pos == -1 )
			return;
		else
		{
			subDir = dir.left ( pos + 1 );
			begin = pos + 1;
			
			chdir ( subDir );
			mkdir ( subDir.ascii ( ), shareMode );
		}
	}
}

void loadConfig()
{
 	CIniFile config ( "/etc/watchdog/watchdog.ini" );

	// setction [General]  
	config.GetString  ( "General", "peerURL", g_peerURL );
	config.GetString  ( "General", "gateWayIP", g_gateWayIP );	
	config.GetString  ( "General", "floatingIP", g_floatingIP );
	config.GetInteger ( "General", "localPort", g_localPort );
	config.GetInteger ( "General", "logLevel", g_logLevel );   

	PRINTF ( "Echo:\t peerURL      =   %s", g_peerURL.data() );
	PRINTF ( "Echo:\t gateWayIP    =   %s", g_gateWayIP.data() );
	PRINTF ( "Echo:\t floatingIP   =   %s", g_floatingIP.data() );
	PRINTF ( "Echo:\t localPort    =   %d", g_localPort );
	PRINTF ( "Echo:\t logLevel     =   %d", g_logLevel );

	// section [Account]                      
	config.GetString  ( "Account", "userName", g_userName );
	config.GetString  ( "Account", "userPassword", g_userPassword );   
    
	PRINTF ( "Echo:\t userName     =   %s", g_userName.data() );
	PRINTF ( "Echo:\t userPassword =   %s", g_userPassword.data() );
    
    // setcion [Processes]
	QString key;
	string svalue;
    int ivalue;

	for ( int i = 1; i < 100; ++i )
	{
		PROCESS process;
		key = "";
		svalue = "";
		ivalue = 15;

		key = key.sprintf ( "proc%d", i );

		if ( config.GetString  ( "Processes", key, svalue ) == true )
		{
			PRINTF ( "Echo:\t local %s  =   %s", key.data(), svalue.data() );
			process.proc = svalue;
		}

		key = key.sprintf ( "cmd%d", i );

		if ( config.GetString  ( "Processes", key, svalue ) == true )
		{
			PRINTF ( "Echo:\t local %s   =   %s", key.data(), svalue.data() );
			process.cmd = svalue;
		}                                  

		key = key.sprintf ( "time%d", i );

		if ( config.GetInteger  ( "Processes", key, ivalue ) == true )
		{
			PRINTF ( "Echo:\t local %s  =   %d", key.data(), ivalue );
			process.timewait = ivalue;
		}

		if ( process.proc != "" )
			g_vectorProcs.push_back ( process );
	}

	// setcion [PeerProcesses]
	for ( int i = 1; i < 100; ++i )
	{
		key = key.sprintf ( "proc%d", i );

		if ( config.GetString  ( "PeerProcesses", key, svalue ) == true && svalue != "" )
		{
			PRINTF ( "Echo:\t peer %s   =   %s", key.data(), svalue.data() );
			g_vectorPeerProcs.push_back ( svalue );
		}
	}
}

void popSocket()
{
	g_mutexRubbish.lock ( );

	if ( g_vectorRubbish.size ( ) > 0 )
	{
		QSocket * socket;
		int oldlen = g_vectorRubbish.size ( );

		for ( vector<QSocket*>::iterator it = g_vectorRubbish.begin(); it != g_vectorRubbish.end(); )
		{
			socket = *it;
			
			if (socket->state() == QSocket::Idle)
			{
				delete socket;
				g_vectorRubbish.erase ( it );				
			}
			else
			{
				++it;
			}
		}

		int newlen = g_vectorRubbish.size ( );

		if (newlen != oldlen && g_logLevel > 2)
		{
			PRINTF ( "Echo:\t SocketQueue's length = %d", oldlen );
			PRINTF ( "Echo:\t SocketQueue's length = %d", newlen );	
		}
	}

	g_mutexRubbish.unlock ( );
}

void pushSocket(QSocket *socket)
{
	if ( socket == NULL )
		return;

	g_mutexRubbish.lock ( );
	g_vectorRubbish.push_back ( socket );
	g_mutexRubbish.unlock ( );
}

void writeLog()
{
	g_mutexLog.lock();
	
	struct stat file_stat;
	stat ( LogFile, &file_stat );
	
	if ( file_stat.st_size > 20971520 )
	{
		close ( g_iLogFd );
		openLogFile ( );
	}
	
	lseek ( g_iLogFd, 0, SEEK_END );
	
	for ( vector<QString>::iterator it = g_vectorLogs.begin(); it != g_vectorLogs.end(); ++it )
	{              
		if ( g_logLevel > 0 )    
			write ( g_iLogFd, (*it).ascii ( ), (*it).length ( ) );

		if ( g_logLevel > 1 )
			cout << (*it) << endl; 
	}

	g_vectorLogs.clear ( );	
	
	g_mutexLog.unlock();	
}                                                                               

void setSvrState(QString myState, QString peerState)
{
	g_mutexSvrState.lock ( );

 	if ( g_myState != myState )
	{
		g_myState = myState;
        g_peerState = peerState;

    	PRINTF ( "Echo:\t myState = %s, peerState = %s", g_myState.ascii(), g_peerState.ascii() );
		if ( myState == "master" )
			system ( "/etc/watchdog/changetomaster" );
		else
			system ( "/etc/watchdog/changetoslave" );
    }

	g_mutexSvrState.unlock ( );	
}

void initMyState()
{           
	QString cmd;
	cmd.sprintf ( "ifconfig |grep %s|wc -l > /var/ifconfig.pid", g_floatingIP.data() );
	system ( cmd.ascii() );

	FILE * pFile = fopen ( "/var/ifconfig.pid", "r" );
	int rc = 0;

	if ( pFile != NULL )
	{	
		fscanf ( pFile, "%d", &rc );
		fclose ( pFile );
	}	
	
 	if ( rc == 0 )
		setSvrState ( "slave", "master" );
	else
		setSvrState ( "master", "slave" );
	
}

size_t writeCallback(void *src, size_t /*size*/, size_t /*nb*/, void *dest )                    
{
	if ( !src || !dest )
		return 0;

	QString *response = (QString *)dest;
	(*response) += (char *)src;
	return response->length ( );
}

bool pingHost(const char * host)
{
// 	parent process space
	pid_t child = fork();
	
	if ( child == -1 )
		return true;

	if ( child == 0 ) // child process space
	{
		QString ping;
		ping.sprintf ( "ping -c 4 %s |grep '0 received'|wc -l > /var/ping.pid", host );
		system ( ping.ascii ( ) );
		_exit ( 0 );
	}
	else // parent process space
	{
		int status;
		waitpid ( child, &status, 0 );

		FILE * pFile = fopen ( "/var/ping.pid", "r" );
	    int rc = 0;

		if ( pFile != NULL )
		{
			fscanf ( pFile, "%d", &rc );
			fclose ( pFile );
		}
		
		return ( rc == 0 );
    }
}

bool pingSelf()
{
	system ( "ifconfig > /var/ifconfig.pid" );
	struct stat file_stat;
	stat ( "/var/ifconfig.pid", &file_stat );
	
	if ( file_stat.st_size > 0 )
	{
		PRINTF ( "Echo:\t network adapter is available." );
		return true;
	}
	else
	{
		PRINTF ( "Echo:\t network adapter is unavailable." );
		return false;
	}
}

bool pingGateway()
{
	if ( pingHost ( g_gateWayIP.data() ) )
	{
		PRINTF ( "Echo:\t %s is reachable", g_gateWayIP.data() );
		return true;
	}
	else
	{
		PRINTF ( "Echo:\t %s is unreachable", g_gateWayIP.data() );
		return false;
	}
}

bool pingFloatingIP()
{
	if ( pingHost ( g_floatingIP.data() ) )
	{
		PRINTF ( "Echo:\t %s is reachable", g_floatingIP.data() );
		return true;
	}
	else
	{
		PRINTF ( "Echo:\t %s is unreachable", g_floatingIP.data() );
		return false;
	}
}

bool heartBeat()
{
    static char body[] = "<requestType>getState</requestType>\r\n";
	CURL *curl = curl_easy_init();
	QString response = "";

	if ( !curl )
		return false;

	curl_easy_setopt ( curl, CURLOPT_URL, g_peerURL.data ( ) );		
	curl_easy_setopt ( curl, CURLOPT_CONNECTTIMEOUT, 3 );
	curl_easy_setopt ( curl, CURLOPT_TIMEOUT, 3 );
//	curl_easy_setopt ( curl, CURLOPT_VERBOSE, 1 );
	curl_easy_setopt ( curl, CURLOPT_POST, 1 );
	curl_easy_setopt ( curl, CURLOPT_POSTFIELDS, body );
	curl_easy_setopt ( curl, CURLOPT_WRITEFUNCTION, &writeCallback );
	curl_easy_setopt ( curl, CURLOPT_WRITEDATA, &response );
	int rc = curl_easy_perform ( curl );
	curl_easy_cleanup ( curl );
        
	if ( g_logLevel > 2 )
		PRINTF ( "Echo:\t proc = %s, rc = %d, rs = %s", g_peerURL.data(), rc, response.ascii() );

	if ( response.length() == 0 )
	{
		PRINTF ( "Echo:\t %s = NotReady", g_peerURL.data() );
		return false;
	}
	else if ( response.contains ( "<myState>master</myState>" ) )
	{
		PRINTF ( "Echo:\t %s = master", g_peerURL.data() );
		return true;
	}
	else
	{
		PRINTF ( "Echo:\t %s = slave", g_peerURL.data() );
		return false;
	}
}

bool findHttpProc(QString proc)
{        
	CURL *curl = curl_easy_init();
    QString response = "";

	if ( curl == NULL )
		return false;

	curl_easy_setopt ( curl, CURLOPT_URL, proc.ascii() );		
	curl_easy_setopt ( curl, CURLOPT_CONNECTTIMEOUT, 3 );
	curl_easy_setopt ( curl, CURLOPT_TIMEOUT, 3 );
// 	curl_easy_setopt ( curl, CURLOPT_VERBOSE, 1 );
    curl_easy_setopt ( curl, CURLOPT_WRITEFUNCTION, &writeCallback );
	curl_easy_setopt ( curl, CURLOPT_WRITEDATA, &response );
	int rc = curl_easy_perform ( curl );
	curl_easy_cleanup ( curl );

	if ( g_logLevel > 2 )
		PRINTF ( "Echo:\t proc = %s, rc = %d, rs = %s", proc.ascii(), rc, response.ascii() );

	if ( rc == 0 || response.length() > 0 )
	{
		PRINTF ( "Echo:\t %s = Ready", proc.ascii() );
		return true;
	}
	else
	{
		PRINTF ( "Echo:\t %s = NotReady", proc.ascii() );
		return false;
	}
}

bool findLocalProcs()
{
	bool rc = true;

	for ( vector<PROCESS>::iterator it = g_vectorProcs.begin(); it != g_vectorProcs.end(); ++it )
	{
		if ( !findHttpProc ( (*it).proc ) )
		{
			rc = false;          
			setSvrState ( "slave", "master" );      
 			sleep ( (*it).timewait );

			system ( (*it).cmd.data() );
			sleep ( (*it).timewait );
	    }
	}

	return rc;
}

bool findRemoteProcs()
{
	bool rc = true;

	for ( vector<string>::iterator it = g_vectorPeerProcs.begin(); it != g_vectorPeerProcs.end(); ++it )
		if ( !findHttpProc ( *it ) )
			rc = false;

	return rc;
}
